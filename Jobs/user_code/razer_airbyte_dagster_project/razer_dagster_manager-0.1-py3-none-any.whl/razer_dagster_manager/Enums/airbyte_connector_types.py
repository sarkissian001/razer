from enum import Enum, auto


class ConnectionType(Enum):
    SOURCE = auto()
    DESTINATION = auto()
